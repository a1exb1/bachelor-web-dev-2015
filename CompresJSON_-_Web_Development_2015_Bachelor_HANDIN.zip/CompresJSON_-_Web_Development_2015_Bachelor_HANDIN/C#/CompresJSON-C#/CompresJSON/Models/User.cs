﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CompresJSON
{
    public class User
    {
        public int UserID { get; set; }
        //public DateTime dob { get; set; }
        public string Name { get; set; }
        public string AdLine1 { get; set; }
    }
}