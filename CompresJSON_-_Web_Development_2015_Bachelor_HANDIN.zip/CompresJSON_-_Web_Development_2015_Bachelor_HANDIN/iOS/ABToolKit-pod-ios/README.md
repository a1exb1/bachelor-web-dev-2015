# ABToolKit

[![CI Status](http://img.shields.io/travis/Alex Bechmann/ABToolKit.svg?style=flat)](https://travis-ci.org/Alex Bechmann/ABToolKit)
[![Version](https://img.shields.io/cocoapods/v/ABToolKit.svg?style=flat)](http://cocoapods.org/pods/ABToolKit)
[![License](https://img.shields.io/cocoapods/l/ABToolKit.svg?style=flat)](http://cocoapods.org/pods/ABToolKit)
[![Platform](https://img.shields.io/cocoapods/p/ABToolKit.svg?style=flat)](http://cocoapods.org/pods/ABToolKit)

## Usage

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

ABToolKit is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "ABToolKit"
```

## Author

Alex Bechmann, alex_bechmann@hotmail.com

## License

ABToolKit is available under the MIT license. See the LICENSE file for more info.
