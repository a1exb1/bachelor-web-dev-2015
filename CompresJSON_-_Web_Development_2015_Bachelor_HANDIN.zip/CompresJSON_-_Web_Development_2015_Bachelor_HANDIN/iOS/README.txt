ABToolKit-pod-ios contains:

# CompresJSON Library code inside folders (ABToolKit-pod-ios\Pod\Classes):
- CompresJSON 
- JsonResult
- JavascriptAnalyzer

# Other helpful functions inside folders:
- Autolayout [created by Shagan (Ustwo)]
- Extensions

---

CompresJSONExample project contains example usage inside (CompresJSONExample-ios\CompresJSONExample\Classes):
- CardDesignItemsViewController
- SaveCardDesignItemViewController
- AppDelegate